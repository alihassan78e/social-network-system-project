public class UserBST {

    private Node root;

    public void insert(UserProfile user) {
        root = insertRecursive(root, user);
    }

    private Node insertRecursive(Node current, UserProfile user) {
        if (current == null) {
            return new Node(user);
        }

        if (user.getUserID() < current.getUser().getUserID()) {
            current.left = insertRecursive(current.left, user);
        } else if (user.getUserID() > current.getUser().getUserID()) {
            current.right = insertRecursive(current.right, user);
        }

        return current;
    }

    public UserProfile findUserByID(int id) {
        return findRecursive(root, id);
    }

    private UserProfile findRecursive(Node current, int id) {
        if (current == null) return null;

        int currentID = current.getUser().getUserID();
        if (id == currentID) return current.getUser();
        else if (id < currentID) return findRecursive(current.left, id);
        else return findRecursive(current.right, id);
    }
}




