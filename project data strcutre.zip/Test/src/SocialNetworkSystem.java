import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SocialNetworkSystem {

    public SocialNetworkSystem() {
    }

    public static Post findPostByID(List<Post> posts, int id) {
        for (Post post : posts) {
            if (post.getPostID() == id) {
                return post;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        List<UserProfile> users = new ArrayList<>();
        List<Post> posts = new ArrayList<>();
        NotificationQueue notificationQueue = new NotificationQueue();
        boolean run = true;

        while (run) {
            System.out.println("\n=== Welcome to the Social Network ===");
            System.out.println("1- Login to Existing User \n2- Register New User ");
            System.out.print("Choose: ");
            int log = input.nextInt();
            input.nextLine();

            switch (log) {

                case 1:
                    System.out.print("\nEnter your User ID to login: ");
                    int userId = input.nextInt();
                    input.nextLine();
                    UserProfile currentUser = UserProfile.searchByUserID(users, userId);

                    if (currentUser != null) {
                        boolean innerRun = true;
                        System.out.println("\n=== ✨ Successfully logged in! Enjoy using the app ===");

                        while (innerRun) {
                            System.out.println("\n=== Social Actions ===");
                            System.out.println("1- Add Users\n2- Post Menu\n3- Friend Request Menu\n4- Report Menu\n5- Update profile\n6- Exit");
                            System.out.print("Choose: ");
                            int num = input.nextInt();
                            input.nextLine();

                            switch (num) {
                                case 1:
                                    System.out.print("How many users do you want to add? ");
                                    int userCount = input.nextInt();
                                    input.nextLine();
                                    for (int i = 0; i < userCount; i++) {
                                        System.out.println("\nEnter info for User " + (i + 1));
                                        System.out.print("User ID: ");
                                        int newUserId = input.nextInt();
                                        input.nextLine();
                                        System.out.print("Username: ");
                                        String username = input.nextLine();
                                        System.out.print("Email: ");
                                        String email = input.nextLine();
                                        System.out.print("Bio: ");
                                        String bio = input.nextLine();

                                        UserProfile user = new UserProfile(newUserId, username, email, bio, notificationQueue);
                                        UserProfile.addNode(user);
                                        users.add(user);
                                    }
                                    break;

                                case 2:
                                    boolean postMenu = true;
                                    while (postMenu) {
                                        System.out.println("\n=== Posts Menu ===");
                                        System.out.println("1. Create Posts\n2. Post Actions\n3. Back to Main Menu");
                                        System.out.print("Choose: ");
                                        int choice = input.nextInt();
                                        input.nextLine();

                                        if (choice == 1) {
                                            System.out.print("\nHow many posts do you want to create? ");
                                            int postCount = input.nextInt();
                                            input.nextLine();
                                            for (int i = 0; i < postCount; i++) {
                                                System.out.println("\nEnter info for Post " + (i + 1));
                                                System.out.print("Post ID: ");
                                                int postId = input.nextInt();
                                                input.nextLine();
                                                System.out.print("User ID: ");
                                                int userID = input.nextInt();
                                                input.nextLine();

                                                if (UserProfile.searchByUserID(users, userID) == null) {
                                                    System.out.println("❌ Error: User ID not found. Skipping this post.");
                                                    i--;
                                                } else {
                                                    System.out.print("Content: ");
                                                    String content = input.nextLine();
                                                    Post post = Post.createPost(postId, userID, content);
                                                    for (UserProfile user : users) {
                                                        if (user.getUserID()==(userID)) {
                                                            user.addPost(post);
                                                            System.out.println("Post added successfully!");
                                                        }
                                                    }
                                                    posts.add(post);
                                                }
                                            }
                                        } else if (choice == 2) {
                                            System.out.println("\n=== Post Actions ===");
                                            System.out.println("1. Like a post\n2. Comment on a post\n3. Delete a post\n4. Show all posts\n5. Back");
                                            System.out.print("Choose: ");
                                            int action = input.nextInt();
                                            input.nextLine();

                                            switch (action) {
                                                case 1:
                                                    System.out.print("Enter Your User ID: ");
                                                    int likerId = input.nextInt();
                                                    System.out.print("Enter Post ID to like: ");
                                                    int postId = input.nextInt();

                                                    UserProfile liker = UserProfile.searchByUserID(users, likerId);
                                                    Post post = findPostByID(posts, postId);

                                                    if (liker == null || post == null) {
                                                        System.out.println("❌ Error: Invalid User ID or Post ID.");
                                                    } else {
                                                        post.addLike(likerId);
                                                        System.out.println("✅ You liked the post successfully!");
                                                        notificationQueue.addNotification(likerId, "You liked Post " + postId);

                                                    }
                                                    break;
                                                case 2:
                                                    System.out.print("Enter Your User ID: ");
                                                    int commenterId = input.nextInt();
                                                    input.nextLine();
                                                    System.out.print("Enter Post ID to comment on: ");
                                                    int commentPostId = input.nextInt();
                                                    input.nextLine();

                                                    UserProfile commenter = UserProfile.searchByUserID(users, commenterId);
                                                    Post commentPost = findPostByID(posts, commentPostId);

                                                    if (commenter == null || commentPost == null) {
                                                        System.out.println("❌ Error: Invalid User ID or Post ID.");
                                                    } else {
                                                        System.out.print("Enter your comment: ");
                                                        String commentText = input.nextLine();
                                                        commentPost.addComment(commenterId, commentText);
                                                        System.out.println("✅ Comment added successfully!");
                                                        notificationQueue.addNotification(commenterId, "You commented on Post " + commentPostId);
                                                    }
                                                    break;
                                                case 3:
                                                    System.out.print("Enter Post ID to delete: ");
                                                    int deleteId = input.nextInt();
                                                    Post deletePost = findPostByID(posts, deleteId);
                                                    if (deletePost == null) {
                                                        System.out.println("❌ Error: Invalid Post ID.");
                                                    } else {
                                                        posts.remove(deletePost);
                                                        System.out.println("Post " + deleteId + " has been deleted.");

                                                    }
                                                    break;
                                                case 4:
                                                    for (Post p : posts) {
                                                        p.printPost();
                                                    }
                                                    break;
                                                case 5:
                                                    postMenu = false;
                                                    break;
                                            }
                                        } else if (choice == 3) {
                                            postMenu = false;
                                        }
                                    }
                                    break;

                                case 3:
                                    boolean friendMenu = true;
                                    while (friendMenu) {
                                        System.out.println("\n=== Friend Request Menu ===");
                                        System.out.println("1. Send\n2. Show\n3. Accept\n4. Decline\n5. Remove Friend\n6. Back to Main Menu");
                                        System.out.print("Choose: ");
                                        int choice = input.nextInt();

                                        switch (choice) {
                                            case 1:
                                                System.out.print("Sender ID: ");
                                                int sender = input.nextInt();
                                                System.out.print("Receiver ID: ");
                                                int receiver = input.nextInt();
                                                if (UserProfile.searchByUserID(users, sender) != null && UserProfile.searchByUserID(users, receiver) != null) {
                                                    FriendRequest.Send(new FriendRequest(sender, receiver), users);
                                                } else {
                                                    System.out.println("❌ Error: One or both User IDs are invalid.");
                                                }
                                                break;

                                            case 2:
                                                FriendRequest.showQueue();
                                                break;

                                            case 3:
                                                System.out.print("Receiver ID to accept: ");
                                                int acceptID = input.nextInt();
                                                if (UserProfile.searchByUserID(users, acceptID) != null) {
                                                    new FriendRequest(0, acceptID).Accept(acceptID, users);
                                                } else {
                                                    System.out.println("❌ Error: Invalid Receiver ID.");
                                                }
                                                break;

                                            case 4:
                                                System.out.print("Enter Receiver ID to decline: ");
                                                int declineID = input.nextInt();

                                                if (UserProfile.searchByUserID(users, declineID) != null) {
                                                    FriendRequest.Decline(declineID, users);
                                                } else {
                                                    System.out.println("❌ Error: Invalid Receiver ID.");
                                                }
                                                break;
                                            case 5:
                                                System.out.print("Enter your User ID: ");
                                                int currentUserID = input.nextInt();
                                                UserProfile cr = UserProfile.searchByUserID(users, currentUserID);

                                                if (cr != null) {
                                                    System.out.print("Enter Friend's User ID to remove: ");
                                                    int friendID = input.nextInt();
                                                    UserProfile friend = UserProfile.searchByUserID(users, friendID);

                                                    if (friend != null) {
                                                        cr.removeFriend(friend);
                                                    } else {
                                                        System.out.println("❌ Error: Friend's User ID is invalid.");
                                                    }
                                                } else {
                                                    System.out.println("❌ Error: Your User ID is invalid.");
                                                }
                                                break;

                                            case 6:
                                                friendMenu = false;
                                                break;
                                        }
                                    }
                                    break;

                                case 4:
                                    List<Object> reportUsers = new ArrayList<>(users);
                                    for (int i = 0; i < users.size(); i++) {
                                        int postCount = users.get(i).getPostHistory().size();
                                        System.out.println(users.get(i).getUsername() + " has " + postCount + " posts.");
                                    }
                                    List<Object> reportPosts = new ArrayList<>(posts);
                                    boolean reportMenu = true;
                                    while (reportMenu) {
                                        System.out.println("\n=== Report Menu ===");
                                        System.out.println("1. User Report\n2. Post Report\n3. Network Growth Report\n4. Back to Main Menu\n5. Exit");
                                        System.out.print("Choose: ");
                                        int choice = input.nextInt();

                                        switch (choice) {
                                            case 1:
                                                new ReportGenerator("user", reportUsers).generateUserReport();
                                                break;
                                            case 2:
                                                new ReportGenerator("post", reportPosts).generateTrendingPostsReport();
                                                break;
                                            case 3:
                                                new ReportGenerator("growth", reportUsers).generateNetworkGrowthReport();
                                                break;
                                            case 4:
                                                reportMenu = false;
                                                break;
                                            case 5:
                                                input.close();
                                                System.exit(0);
                                                break;
                                        }
                                    }
                                    break;

                                case 5:
                                    System.out.print("Enter User ID to update: ");
                                    int updateUserId = input.nextInt();
                                    input.nextLine();
                                    UserProfile userToUpdate = UserProfile.searchByUserID(users, updateUserId);

                                    if (userToUpdate != null) {
                                        System.out.println("\nUpdating profile for: " + userToUpdate.getUsername());

                                        System.out.print("New Username (or press Enter to skip): ");
                                        String newUsername = input.nextLine();
                                        newUsername = newUsername.isEmpty() ? null : newUsername;

                                        System.out.print("New Email (or press Enter to skip): ");
                                        String newEmail = input.nextLine();
                                        newEmail = newEmail.isEmpty() ? null : newEmail;

                                        System.out.print("New Bio (or press Enter to skip): ");
                                        String newBio = input.nextLine();
                                        newBio = newBio.isEmpty() ? null : newBio;

                                        userToUpdate.updateProfile(newUsername, newEmail, newBio);

                                        System.out.println("\nReturning to the previous menu...");
                                    } else {
                                        System.out.println("❌ User with ID " + updateUserId + " not found.");
                                    }
                                    break;

                                case 6:
                                    input.close();
                                    System.exit(0);
                                    break;
                                default:
                                    System.out.println("❌ Invalid option.");
                                    break;

                            }
                        }
                    } else {
                        System.out.println("❌ No user with that ID. Try registering first.");
                    }
                    break;
                case 2:
                    System.out.println("\n--- Register New User ---");
                    System.out.print("User ID: ");
                    int num = input.nextInt();
                    input.nextLine();
                    if (UserProfile.searchByUserID(users, num) != null) {
                        System.out.println("❌ User ID already exists. Try again.");
                    } else {
                        System.out.print("Username: ");
                        String username = input.nextLine();
                        System.out.print("Email: ");
                        String email = input.nextLine();
                        System.out.print("Bio: ");
                        String bio = input.nextLine();
                        UserProfile user = new UserProfile(num, username, email, bio,notificationQueue);
                        UserProfile.addNode(user);
                        users.add(user);
                        System.out.println("✅ User '" + username + "' registered!");
                    }
                    break;
            }
        }
    }
}
