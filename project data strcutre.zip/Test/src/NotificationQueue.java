import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class NotificationQueue {
    private ArrayList<Queue<String>> userNotificationsList = new ArrayList<>();


    public NotificationQueue() {
    }

    public void addNotification(int userId, String notification) {
        ensureUserNotificationListSize(userId);
        userNotificationsList.get(userId).add(notification);
        System.out.println("Notification added for User " + userId + ": " + notification);
    }

    public void removeNotification(int userId, int notificationIndex) {
        if (userId < userNotificationsList.size() && !userNotificationsList.get(userId).isEmpty()) {
            Queue<String> notifications = userNotificationsList.get(userId);

            if (notificationIndex >= 0 && notificationIndex < notifications.size()) {
                ArrayList<String> notificationList = new ArrayList<>(notifications);

                String removedNotification = notificationList.remove(notificationIndex);

                notifications.clear();
                notifications.addAll(notificationList);

                System.out.println("Notification removed for User " + userId + ": " + removedNotification);
            } else {
                System.out.println("Invalid notification index for User " + userId);
            }
        } else {
            System.out.println("No notifications to remove for User " + userId);
        }
    }

    public void sendNotification(int userId) {
        if (userId < userNotificationsList.size() && !userNotificationsList.get(userId).isEmpty()) {
            String notification = userNotificationsList.get(userId).peek();
            System.out.println("Sending notification to User " + userId + ": " + notification);
        } else {
            System.out.println("No notifications to send for User " + userId);
        }
    }

    public void showAll(int userId) {
        if (userId < userNotificationsList.size() && !userNotificationsList.get(userId).isEmpty()) {
            System.out.println("All Notifications for User " + userId + ":");
            for (String notification : userNotificationsList.get(userId)) {
                System.out.println("- " + notification);
            }
        } else {
            System.out.println("No notifications to show for User " + userId);
        }
    }
    private void ensureUserNotificationListSize(int userId) {
        while (userNotificationsList.size() <= userId) {
            userNotificationsList.add(new LinkedList<>());
        }
    }
}