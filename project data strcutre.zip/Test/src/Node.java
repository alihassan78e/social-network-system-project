public class Node {
    private UserProfile user;
    int data;
    Node next;
    Node left;
    Node right;

    public Node(UserProfile user) {
        this.data = data;
        this.user=user;
        this.left = null;
        this.right = null;
    }
    public UserProfile getUser() {
        return user;
    }
}