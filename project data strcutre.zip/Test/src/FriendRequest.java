import java.awt.*;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.List;

public class FriendRequest {
    int requestID;
    int senderID;
    int receiverID;
    String status;
    public static int currentID = 1;
    NotificationQueue notificationQueue;
    static PriorityQueue<FriendRequest> queue = new PriorityQueue<>((FriendRequest a, FriendRequest b) -> a.requestID - b.requestID);

    public FriendRequest(int senderID, int receiverID) {
        this.requestID = currentID++;
        this.senderID = senderID;
        this.receiverID = receiverID;
        this.status = "pending";
        this.notificationQueue = new NotificationQueue();
    }

    public int getSenderID() {
        return senderID;
    }

    public void accept() {

        this.status = "accepted";
    }

    public void decline() {

        this.status = "declined";
    }

    public static void Send(FriendRequest request,List<UserProfile> users) {
        queue.add(request);
        String notification = "You have a new friend request from User " + request.senderID;
        UserProfile receiver = UserProfile.searchByUserID(users, request.receiverID);
        if (receiver != null) {
            receiver.getNotificationQueue().addNotification(request.receiverID, notification);
        }
        System.out.println("Request pushed: " + String.valueOf(request));
    }


    public void Accept(int receiverProfile, List<UserProfile> users) {
    if (queue.isEmpty()) {
        System.out.println("No requests to accept.");
    } else {
        FriendRequest reqToAccept = null;
        for (FriendRequest req : queue) {
            if (req.receiverID == receiverProfile && req.status.equals("pending")) {
                reqToAccept = req;
                break;
            }
        }
        if (reqToAccept != null) {
            reqToAccept.accept();
            UserProfile sender = UserProfile.searchByUserID(users, reqToAccept.getSenderID());
            UserProfile receiver = UserProfile.searchByUserID(users, receiverProfile);

            if (sender != null && receiver != null) {
                sender.addFriend(receiver);
                receiver.addFriend(sender);
                System.out.println("✔️ Friend request accepted and users are now friends.");
            }
            queue.remove(reqToAccept);
        } else {
            System.out.println("❌ No pending request for this user or already accepted.");
        }
    }
}

    public static void Decline(int declineID, List<UserProfile> users) {
    if (queue.isEmpty()) {
        System.out.println("No requests to decline.");
    } else {
        FriendRequest reqToDecline = null;
        for (FriendRequest req : queue) {
            if (req.receiverID == declineID && req.status.equals("pending")) {
                reqToDecline = req;
                break;
            }
        }

        if (reqToDecline != null) {
            reqToDecline.decline();
            System.out.println("❌ Friend request from User " + reqToDecline.senderID + " declined.");
            queue.remove(reqToDecline);
        } else {
            System.out.println("❌ No pending request found for the given Receiver ID.");
        }
    }
}


    public static void showQueue() {
        if (queue.isEmpty()) {
            System.out.println("No pending requests.");
        } else {
            System.out.println("Pending Requests:");
            Iterator var0 = queue.iterator();

            while(var0.hasNext()) {
                FriendRequest r = (FriendRequest)var0.next();
                System.out.println(r);
            }
        }

    }

    public String toString() {
        return "ID: " + this.requestID + " | From: " + this.senderID + " To: " + this.receiverID + " | Status: " + this.status;
    }
}