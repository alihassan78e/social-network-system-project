
import javax.management.Notification;
import java.util.ArrayList;
import java.util.List;

public class UserProfile {
    private static ArrayList<UserProfile> userList = new ArrayList<>();

    public int userID;
    private NotificationQueue notificationQueue;
    private String username;
    private String email;
    private String bio;
    private ArrayList<UserProfile> friendList;
    private ArrayList<Post> postHistory;

    public UserProfile(int userID, String username, String email, String bio , NotificationQueue notificationQueue) {
        this.userID = userID;
        this.username = username;
        this.email = email;
        this.bio = bio;
        this.friendList = new ArrayList<>();
        this.postHistory = new ArrayList<>();
        this.notificationQueue = notificationQueue;
    }

    public NotificationQueue getNotificationQueue() {
        return notificationQueue;
    }

    public static void addNode(UserProfile user) {
        userList.add(user);
        System.out.println("✅ User '" + user.username + "' added successfully to the network!");
    }

    public static UserProfile searchByUserID(List<UserProfile> users, int id) {
        for (UserProfile user : userList) {
            if (user.userID == id) {
                return user;
            }
        }
        return null;
    }

    public void removeFriend(UserProfile friend) {
        if (friendList.contains(friend)) {
            friendList.remove(friend);
            friend.friendList.remove(this);

            FriendRequest requestToRemove = null;
            for (FriendRequest request : FriendRequest.queue) {
                if ((request.senderID == this.getUserID() && request.receiverID == friend.getUserID()) ||
                        (request.senderID == friend.getUserID() && request.receiverID == this.getUserID())) {
                    requestToRemove = request;
                    break;
                }
            }

            if (requestToRemove != null) {
                FriendRequest.queue.remove(requestToRemove);
                System.out.println("✔️ Friend request between " + this.getUsername() + " and " + friend.getUsername() + " removed.");
            } else {
                System.out.println("✔️ Friend removed successfully.");
            }
        } else {
            System.out.println("❌ This user is not in your friend list.");
        }
    }

    public void updateProfile(String newUsername, String newEmail, String newBio) {
        if (newUsername != null && !newUsername.isEmpty()) {
            this.username = newUsername;
        }
        if (newEmail != null && !newEmail.isEmpty()) {
            this.email = newEmail;
        }
        if (newBio != null && !newBio.isEmpty()) {
            this.bio = newBio;
        }

        for (UserProfile user : userList) {
            if (user.userID == this.userID) {
                user.username = this.username;
                user.email = this.email;
                user.bio = this.bio;
                break;
            }
        }

        System.out.println("✅ Profile updated successfully!");
    }


    public int getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getBio() {
        return bio;
    }

    public ArrayList<UserProfile> getFriendList() {
        return friendList;
    }

    public ArrayList<Post> getPostHistory() {
        return postHistory;
    }

    public void addFriend(UserProfile friend) {
        if (!friendList.contains(friend)) {
            friendList.add(friend);
        }
    }

    public void addPost(Post post) {
        postHistory.add(post);
    }

    public static void getUserInfo(int userID) {
        UserProfile user = searchByUserID(userList, userID);

        if (user != null) {
            System.out.println("\n=== User Information ===");
            System.out.println("👤 Username: " + user.getUsername());
            System.out.println("📧 Email:" + user.getEmail());
            System.out.println("📝 Bio: " + user.getBio());
            System.out.println("Friend List: " + user.getFriendList().size() + " friends");
            System.out.println("📑 Posts History: " + user.getPostHistory().size() + " posts \n");
        } else {
            System.out.println("❌ User not found!");
        }
    }





}
