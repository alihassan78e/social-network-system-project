import java.util.*;

public class ReportGenerator {

    private String reportType;
    private List<Object> data;

    public ReportGenerator(String reportType, List<Object> data) {
        this.reportType = reportType;
        this.data = data;
    }

    public void generateUserReport() {
        System.out.println("=== User Activity Report ===");

        List<Object> sortedUsers = quickSort(data, 0, data.size() - 1, new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                if (o1 instanceof UserProfile && o2 instanceof UserProfile) {
                    UserProfile u1 = (UserProfile) o1;
                    UserProfile u2 = (UserProfile) o2;
                    return Integer.compare(u2.getPostHistory().size(), u1.getPostHistory().size());
                }
                return 0;
            }
        });

        for (Object obj : sortedUsers) {
            if (obj instanceof UserProfile) {
                UserProfile user = (UserProfile) obj;
                UserProfile.getUserInfo(user.getUserID());           }
        }
    }

    public void generateTrendingPostsReport() {
        System.out.println("=== 🔥 Trending Posts Report ===");

        List<Object> sortedPosts = quickSort(data, 0, data.size() - 1, new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                if (o1 instanceof Post && o2 instanceof Post) {
                    Post p1 = (Post) o1;
                    Post p2 = (Post) o2;
                    return Integer.compare(p2.getLikes(), p1.getLikes());
                }
                return 0;
            }
        });

        for (Object obj : sortedPosts) {
            if (obj instanceof Post) {
                Post post = (Post) obj;
                String preview = post.getContent().length() > 30 ? post.getContent().substring(0, 30) + "..." : post.getContent();

                System.out.println("📝 Post ID: " + post.getPostID() +
                        " | Likes: " + post.getLikes() +
                        " | Comments: " + post.getComments().size());
                System.out.println("   Content: \"" + preview + "\"\n");
            }
        }
    }
    public void generateNetworkGrowthReport() {
        System.out.println("=== 📊 Network Growth Report ===");

        List<Object> sortedUsers = quickSort(data, 0, data.size() - 1, new Comparator<Object>() {
            @Override
            public int compare(Object o1, Object o2) {
                if (o1 instanceof UserProfile && o2 instanceof UserProfile) {
                    UserProfile u1 = (UserProfile) o1;
                    UserProfile u2 = (UserProfile) o2;
                    return Integer.compare(u2.getPostHistory().size(), u1.getPostHistory().size());
                }
                return 0;
            }
        });
        int totalUsers = 0;
        int totalPosts = 0;
        int totalFriends = 0;
        for (Object obj : sortedUsers) {
            if (obj instanceof UserProfile) {
                UserProfile user = (UserProfile) obj;
                totalUsers++;
                totalPosts += user.getPostHistory().size();
                totalFriends += user.getFriendList().size();
            }
        }
        double avgPosts = totalUsers > 0 ? (double) totalPosts / totalUsers : 0;
        double avgFriends = totalUsers > 0 ? (double) totalFriends / totalUsers : 0;
        System.out.println("👥 Total Users: " + totalUsers);
        System.out.println("📝 Total Posts: " + totalPosts);
        System.out.printf("📈 Average Posts per User: %.2f\n", avgPosts);
        System.out.println("🤝 Total Friend Connections: " + totalFriends);
        System.out.printf("📊 Average Friends per User: %.2f\n", avgFriends);
    }

    public List<Object> quickSort(List<Object> list, int start, int end, Comparator<Object> comparator) {
        if (start < end) {
            int loc = partition(list, start, end, comparator);

            quickSort(list, start, loc - 1, comparator);
            quickSort(list, loc + 1, end, comparator);
        }
        return list;
    }

    public int partition(List<Object> list, int start, int end, Comparator<Object> comparator) {
        Object pivot = list.get(end);
        int loc = start;

        for (int i = start; i < end; i++) {
            if (comparator.compare(list.get(i), pivot) <= 0) {
                Collections.swap(list, i, loc);
                loc++;
            }
        }
        Collections.swap(list, loc, end);
        return loc;
    }


}