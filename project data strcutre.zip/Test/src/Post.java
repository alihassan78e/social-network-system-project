import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Post {
    int postID;
    int userID;
    String content;
    Date timestamp;
    int likes;
    ArrayList<String> comments;
    NotificationQueue notificationQueue;

    public Post(int postID, int userID, String content) {
        this.postID = postID;
        this.userID = userID;
        this.content = content;
        this.timestamp = new Date();
        this.likes = 0;
        this.comments = new ArrayList();
        this.notificationQueue = new NotificationQueue();
    }

    public static Post createPost(int postID, int userID, String content) {
        return new Post(postID, userID, content);
    }

    public void deletePost(int postID) {
        if (this.postID != postID) {
            System.out.println("Cannot delete post.");
        } else {
            this.content = null;
            this.timestamp = null;
            this.likes = 0;
            this.comments = null;
            this.postID = -1;
            this.userID = -1;
            System.out.println("Post " + postID + " has been deleted.");
        }

    }

    public boolean addLike(int userID) {
        if (this.content == null) {
            System.out.println("❌ Cannot like: Post has no content.");
            return false;
        }
        this.likes++;
        return true;
    }


    public boolean addComment(int userID, String comment) {
        if (this.content == null) {
            System.out.println("❌ Cannot comment: Post has no content.");
            return false;
        }
        this.comments.add(comment);
        return true;
    }

    public void printPost() {
        if (this.content == null) {
            System.out.println("There is no Posts to Show .");
        } else {
            System.out.println("Post ID: " + this.postID);
            System.out.println("User ID: " + this.userID);
            System.out.println("Content: " + this.content);
            System.out.println("Timestamp: " + String.valueOf(this.timestamp));
            System.out.println("Likes: " + this.likes);
            System.out.println("Comments: " + String.valueOf(this.comments));
        }

    }

    public int getLikes() {

        return this.likes;
    }

    public int getPostID() {

        return this.postID;
    }

    public List<String> getComments() {

        return this.comments;
    }

    public String getContent() {
        return this.content;
    }
}